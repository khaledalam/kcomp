#pragma once

#include <string>

int Bench(const std::string &path);
